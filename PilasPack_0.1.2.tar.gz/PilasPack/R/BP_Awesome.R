#' Prints BioPortal is awesome :)
#'
#' @return The same Data Frame with date columns transformed into R Date objects (%Y-%m-%d)
#' @export

BP_Awesome<-function(){
  cat("BioPortal is awesome! :D")
}
